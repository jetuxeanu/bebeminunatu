
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";

const produseDemo = [
  { id: 1, nume: "Body roz", pret: 39.99 },
  { id: 2, nume: "Suzetă albastră", pret: 19.99 },
  { id: 3, nume: "Scutece ECO", pret: 59.99 },
  { id: 4, nume: "Jucărie din lemn", pret: 44.99 },
];

export default function Home() {
  const [cos, setCos] = useState([]);
  const costLivrare = 15;

  const adaugaInCos = (produs) => {
    setCos((prev) => {
      const exista = prev.find((p) => p.id === produs.id);
      if (exista) {
        return prev.map((p) =>
          p.id === produs.id ? { ...p, cantitate: p.cantitate + 1 } : p
        );
      }
      return [...prev, { ...produs, cantitate: 1 }];
    });
  };

  const totalProduse = cos.reduce((acc, p) => acc + p.pret * p.cantitate, 0);
  const totalFinal = totalProduse + (cos.length > 0 ? costLivrare : 0);

  return (
    <main className="min-h-screen bg-gradient-to-b from-pink-100 to-blue-100 p-4">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-pink-600">BebeMinunatu</h1>
        <div className="bg-white rounded-full px-4 py-2 shadow text-blue-700">
          🛒 {cos.reduce((acc, p) => acc + p.cantitate, 0)} produse
        </div>
      </header>

      <Tabs defaultValue="magazin" className="max-w-5xl mx-auto">
        <TabsList className="flex justify-center mb-6">
          <TabsTrigger value="forum">Forum</TabsTrigger>
          <TabsTrigger value="magazin">Magazin</TabsTrigger>
          <TabsTrigger value="checkout">Finalizează</TabsTrigger>
        </TabsList>

        <TabsContent value="forum">
          <Card className="mb-4">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold text-pink-500">Discută cu alți părinți</h2>
              <ul className="list-disc ml-5 mt-2 text-blue-900">
                <li>Alăptare și hrănire</li>
                <li>Somn și rutine</li>
                <li>Diversificare</li>
                <li>Naștere și recuperare</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="magazin">
          <Card>
            <CardContent className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              {produseDemo.map((produs) => (
                <div key={produs.id} className="bg-white p-4 rounded-2xl shadow">
                  <h3 className="text-lg font-medium text-blue-600">{produs.nume}</h3>
                  <p className="text-sm text-gray-600">Preț: {produs.pret.toFixed(2)} lei</p>
                  <Button className="mt-2" onClick={() => adaugaInCos(produs)}>
                    Adaugă în coș
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checkout">
          <Card>
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold text-pink-500 mb-4">Sumar comandă</h2>
              {cos.length === 0 ? (
                <p className="text-gray-600">Coșul tău este gol 🛒</p>
              ) : (
                <>
                  <ul className="space-y-2">
                    {cos.map((p) => (
                      <li key={p.id} className="text-blue-900">
                        {p.nume} x {p.cantitate} — {(p.pret * p.cantitate).toFixed(2)} lei
                      </li>
                    ))}
                  </ul>
                  <p className="mt-4 text-sm text-gray-600">
                    Livrare: {costLivrare.toFixed(2)} lei
                  </p>
                  <p className="text-lg font-semibold text-pink-600 mt-2">
                    Total: {totalFinal.toFixed(2)} lei
                  </p>
                  <Button className="mt-4">Plătește cu cardul (Stripe demo)</Button>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
}
